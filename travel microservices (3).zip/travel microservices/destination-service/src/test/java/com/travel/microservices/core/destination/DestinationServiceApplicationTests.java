package com.travel.microservices.core.destination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DestinationServiceApplicationTests {



}
