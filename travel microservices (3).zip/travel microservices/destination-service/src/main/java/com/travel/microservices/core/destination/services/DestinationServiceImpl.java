package com.travel.microservices.core.destination.services;

import com.travel.api.core.destination.Destination;
import com.travel.api.core.destination.DestinationService;
import com.travel.api.exceptions.InvalidInputException;
import com.travel.api.exceptions.NotFoundException;
import com.travel.util.http.ServiceUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//Change the namimng of Controller , it is ambiguis
@RestController
//@RequestMapping("/destinations")
public class DestinationServiceImpl implements DestinationService {
    private static final Logger LOG = LoggerFactory.getLogger(DestinationServiceImpl.class);

    private final ServiceUtil serviceUtil;
    private List<Destination> destinations = new ArrayList<>();

    /**
     * Constructor Autowired is always preferable
     * @param serviceUtil
     */
    @Autowired
    public DestinationServiceImpl(ServiceUtil serviceUtil) {
        this.serviceUtil = serviceUtil;
    }

    /*@GetMapping(value = "/destinations",
            produces={"application/json"})
    public ResponseEntity<Iterable<Destination>> getAllDestinations() {
        destinations.addAll(Stream.of(new Destination(
                        900,"Bengaluru","IN",23.23,13.20,
                        "Info","Image Path",serviceUtil.getServiceAddress()),
                new Destination(901,"Noida","IN",23.23,13.20,
                        "Info","Image Path",serviceUtil.getServiceAddress())
        ).collect(Collectors.toList()));
        return ResponseEntity.ok(destinations);
    }*/

    @Override
    public Destination getDestination(long destId) {
        LOG.debug("/destination return the found product for destId={}", destId);

        if (destId < 1) {
            throw new InvalidInputException("Invalid productId: " + destId);
        }

        if (destId == 13) {
            throw new NotFoundException("No product found for productId: " + destId);
        }
//Returning hardcoded value as of now but later it would be from Database
        return new Destination(destId,"Bengaluru","IN",23.23,13.20,
                "Info","Image Path",serviceUtil.getServiceAddress());
    }

    @Override
    public List<Destination> getAllDestinations() {
        destinations.addAll(Stream.of(new Destination(
                        900,"Bengaluru","IN",23.23,13.20,
                        "Info","Image Path",serviceUtil.getServiceAddress()),
                new Destination(901,"Noida","IN",23.23,13.20,
                        "Info","Image Path",serviceUtil.getServiceAddress())
        ).collect(Collectors.toList()));
        return destinations;
    }
}
