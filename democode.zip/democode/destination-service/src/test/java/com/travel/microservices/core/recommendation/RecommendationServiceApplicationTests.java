package com.travel.microservices.core.recommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecommendationServiceApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
