package com.travel.api.core.destination;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;

public interface DestinationService {


    /**
     * Sample usage: "curl $HOST:$PORT/destination/1".
     *
     * @param destId Id of the destination
     * @return the destination, if found, else null
     */
    @GetMapping(
            value = "/destinations/{destId}",
            produces = "application/json")
    Destination getDestination(@PathVariable long destId);

    @GetMapping(
            value = "/destinations/all",
            produces = "application/json")
    List<Destination> getAllDestinations();

}
