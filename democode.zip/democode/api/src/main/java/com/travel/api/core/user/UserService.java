package com.travel.api.core.user;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public interface UserService {

	
	@RequestMapping(value = "/user/insert", method = RequestMethod.POST)
	int insertUser(@RequestBody User user);
	
	@RequestMapping(value = "/user/update", method = RequestMethod.POST)
	int updateUser(@RequestBody User user);
	
	@RequestMapping(value = "/user/findAll", method = RequestMethod.GET)
	List<User> findAll();
    
	@RequestMapping(value = "/user/findByName/{name}", method = RequestMethod.GET)
	User findByName(@PathVariable String name);
}
  