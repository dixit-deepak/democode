package com.travel.microservices.core.user.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RestController;

import com.travel.api.core.user.User;
import com.travel.api.core.user.UserService;

@RestController
public class UserServiceImpl implements UserService {

	private static final Logger LOG = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public int insertUser(User user) {
		// TODO Auto-generated method stub
		LOG.debug("/Users response size: {}", user.isAdmin());
		return jdbcTemplate.update("INSERT INTO User (username, password, email, isadmin)" + "values(?, ?, ?, ?)",
				new Object[] { user.getUsername(), user.getPassword(), user.getEmail(), user.isAdmin() });
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		return jdbcTemplate.update("update user " + " set username = ?, password = ?, isadmin = ?" + " where email = ?",
				new Object[] { user.getUsername(), user.getPassword(), user.isAdmin(), user.getEmail() });

	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub

		String sql = "SELECT * FROM User";
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		List<User> result = new ArrayList<User>();
		for (Map<String, Object> row : rows) {
			User user = new User();
			user.setUsername((String) row.get("username"));
			user.setPassword((String) row.get("password"));
			user.setEmail((String) row.get("email"));
			user.setAdmin((Boolean) row.get("isadmin"));
			result.add(user);
		}

		return result;
	}

	@Override
	public User findByName(String name) {
		LOG.debug("/Users response for findbyname: {}", name);
		String query = "SELECT * FROM User WHERE username=?";
		// TODO Auto-generated method stub

		@SuppressWarnings("deprecation")
		User user = jdbcTemplate.queryForObject(query, new Object[] { name }, new UserRowMapper());
		return user;

	}
}